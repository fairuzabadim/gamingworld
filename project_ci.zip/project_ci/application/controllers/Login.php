<?php
	/**
	 * 
	 */
	class Login extends CI_Controller
	{
		
		function index(){
			$this->load->view('login');
		}
	}
?>