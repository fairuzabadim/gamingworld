<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Profileku extends CI_Controller
{
	public function datamhs($nma,$npm)
	{
		echo "<h1>Nama : ".$nma."</h1>";
		echo "<h1>Npm : ".$npm."</h1>";
	}
}

?>
