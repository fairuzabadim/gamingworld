<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tugas extends CI_Controller
{
	public function index()
	{
		$this->load->model('tugasmodel');
		$data = $this->tugasmodel->Getpegawai();
		echo"<center>";
		echo"<br></br>";
		echo"<br></br>";
		echo"DAFTAR INFORMASI PEGAWAI";
		echo"<br></br>";
		echo"<table border=2>";
		echo"<tr>";
			echo"<th>Id Pegawai</th>";
			echo"<th>Nama Pegawai</th>";
			echo"<th>Alamat Pegawai</th>";
			echo"<th>Jenis Kelamin Pegawai</th>";
			echo"</tr>";
			
		
		foreach ($data as $pegawai)
		{
			echo "<tr>";
			echo "<td><center>".$pegawai['Id_pegawai']."</center></td>";
			echo "<td><center>".$pegawai['Nama_pegawai']."</center></td>";
			echo "<td><center>".$pegawai['Alamat_pegawai']."</center></td>";
			echo "<td><center>".$pegawai['Jkel_pegawai']."</center></td>";
			echo "</tr>";
			
		}
		echo "</table";
	}
	
}
?>
