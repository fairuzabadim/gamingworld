<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class tugasmodel extends CI_model
{
	public function Getpegawai()
	{
		$data = $this->db->query("SELECT * FROM pegawai");
		return $data->result_array();
	}
}
?>