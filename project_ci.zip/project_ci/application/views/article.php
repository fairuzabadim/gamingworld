<!DOCTYPE html>
<html lang="en">
<head>
	<title>Article</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>
<body>
	<section class="">
		<header>
			<div class="wrapper">
				<a href="#" class="hamburger"></a>
				<nav>
					<ul>
						<li><a href="home">Home</a></li>
						<li><a href="article">Article</a></li>
						<li><a href="games">Games</a></li>
						<li><a href="#">About</a></li>
					</ul>
					<a href="logoutuser.php" class="logout_btn">Logout</a>
				</nav>
			</div>
		</header>
			<section class="caption">
			</section>
	</section>
	<div>
		<br>
		<h2 style="color: white; margin-left:250px;">ARTICLE :</h2>
		<img style="margin-top: -90px; margin-left: 140px;" src="img/art.png">
	</div>
	<div>
		<img src="img/rrq.jpg" style="width: 300px; margin-left: 250px; height:175px; margin-top: -40px;">
		<img src="img/niji.jpg" style="width: 300px; margin-left: 40px; height:175px; margin-top: -40px;">
		<img src="img/sova.jpg" style="width: 300px; margin-left: 40px; height:175px; margin-top: -40px;">
		<a href="*"><h3 style="margin-left: 280px;">RRQ Mengamuk ! <p>XINN membawa RRQ Menuju</p> UPPER BRACKET !</h3></a>
		<a href="*"><h3 style="margin-left: 620px; margin-top: -70px;">Industri game dan  <p>Esport terus berkembang</p> di masa pandemi ini </h3></a>
		<a href="*"><h3 style="margin-left: 970px; margin-top: -70px;">Riot Games Umumkan <p>Turnamen Valorant Pasific</p>Open Ignation Series</h3></a>
    </div>
    <div>
		<img src="img/tobi.jpg" style="width: 300px; margin-left: 250px; height:175px; margin-top: 30px;">
		<img src="img/free.jpg" style="width: 300px; margin-left: 40px; height:175px; margin-top: 30px;">
		<img src="img/sk.jpg" style="width: 300px; margin-left: 40px; height:175px; margin-top: 30px;">
		<a href="*"><h3 style="margin-left: 280px;">(Dota 2) <p>Tersandung pelecehan seksual</p> Caster TobiWan Banned!</h3></a>
		<a href="*"><h3 style="margin-left: 620px; margin-top: -70px;">(Free Fire) Elhaya:<p>Pemain Indonesia harus tingkatkan</p>Level agar kembali berjaya!</h3></a>
		<a href="*"><h3 style="margin-left: 970px; margin-top: -70px;">(League of Legends) <p>SK Telecom T1 Perpanjang</p>kontrak Teddy hingga 2022</h3></a>
    </div>
    <br>
<br>
</body>
<footer style="background: rgba(28, 54, 85, .2);">
	<h4 style="color: white; margin-left: 540px; margin-top: -70px;"> Edited By : SISTEM INFORMATION 2018/PSI </h4>
</footer>
</html>