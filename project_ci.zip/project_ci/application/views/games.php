<!DOCTYPE html>
<html lang="en">
<head>
	<title>Games</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>
<body>
	<section class="">
		<header>
			<div class="wrapper">
				<a href="#" class="hamburger"></a>
				<nav>
					<ul>
						<li><a href="home">Home</a></li>
						<li><a href="article">Article</a></li>
						<li><a href="games">Games</a></li>
						<li><a href="#">About</a></li>
					</ul>
					<a href="logoutuser.php" class="logout_btn">Logout</a>
				</nav>
			</div>
		</header>
			<section class="caption">
			</section>
	</section>
	<div>
		<br>
		<h2 style="color: white; margin-left:250px;">GAMES :</h2>
		<img style="margin-top: -90px; margin-left: 140px;" src="img/art.png">
	</div>
	<div>
		<img src="img/dt2.png" style="margin-left: 260px; width: 120px; margin-top: -60px;">
		<h3 style="color: white; margin-left: 450px; margin-top: -110px;"> Dota 2</h3>
		<h5 style="color: white; margin-left: 450px; margin-top: 20px;"> Dota 2 adalah sekuel Dota atau Defense of the Ancients yang merupakan mode game pada Warcraft 3. <p>Dota dan Dota 2 tergolong sebagai game Multiplayer Online Battle Arena (MOBA).<p> Tujuan dari setiap permainan Dota 2 adalah untuk menghancurkan Throne atau Ancient milik tim lawan.</p> Sejak 2011, Dota 2 mempunyai ajang turnamen bergengsi yang diselenggarakan oleh Valve Corporation setiap tahun, <p>yaitu The International.</p></p></h5>
    </div>
    <div>
    	<br>
    	<img src="img/ml.png" style="margin-left: 200px; width: 230px; height: 170px; margin-top: 40px;">
		<h3 style="color: white; margin-left: 450px; margin-top: -140px;"> Mobile Legends Bang Bang</h3>
		<h5 style="color: white; margin-left: 450px; margin-top: 20px;"> Mobile Legends: Bang Bang adalah game garapan developer Moontoon.<p> Tujuan utama game ini adalah menghancurkan base lawan.<p> Mobile Legends adalah game MOBA mobile yang paling diminati di kawasan Asia Tenggara.</p> Hal ini dapat dibuktikan lewat skena esports yang begitu hidup dengan adanya Mobile Legends Southeast Asia Cup (MSC),<p> Mobile Legends Professional League (MPL), dan Piala Presiden Esports 2019.</p></p>
    </div>
<div>
	<br>
    	<img src="img/ff.png" style="margin-left: 230px; width: 170px; margin-top: 80px;">
		<h3 style="color: white; margin-left: 450px; margin-top: -90px;">Free Fire</h3>
		<h5 style="color: white; margin-left: 450px; margin-top: 20px;"> Free Fire adalah game mobile bergenre Battle Royale dan Third Person Shooter (TPS) yang diterbitkan oleh Garena.<p> Sebagai salah satu game yang memiliki pemain terbanyak di Indonesia,<p> game ini diperlombakan pada gelaran Piala Presiden Esports 2020.</p> tim esports di Indonesia yang menyiapkan tim untuk Free Fire membuat <p>Pemerintah Indonesia mempertimbangkan game ini dikompetisikan dalam gelaran tersebut.</p></p>
</div>
<div>
	<br>
	<img src="img/valorant.png" style="margin-left: 230px; width: 150px; margin-top: 50px;">
		<h3 style="color: white; margin-left: 450px; margin-top: -70px; margin-top: -110px;">Valorant</h3>
		<h5 style="color: white; margin-left: 450px; margin-top: 20px;"> VALORANT adalah ajang kompetitif global milikmu. Game ini adalah pertarungan tembak-menembak taktis 5v5 <p> untuk menempatkan atau menjinakkan Spike. Berbekal satu nyawa di tiap ronde, <p>siapa pun yang lebih dahulu unggul di 13 ronde adalah pemenang pertandingan.</p> Lebih dari sekadar senjata dan peluru,</p> kamu akan memilih Agen bersenjatakan kemampuan yang adaptif, tangkas, <p> dan mematikan untuk membuktikan keahlian menembakmu.</p>
</div>
<div>
	<br>
	<img src="img/fornite.png" style="margin-left: 230px; width: 150px; margin-top: 20px;">
		<h3 style="color: white; margin-left: 450px; margin-top: -100px">Fornite</h3>
		<h5 style="color: white; margin-left: 450px; margin-top: 20px;"> Fornite Fortnite Battle Royale adalah game online multipemain yang sangat besar,<p> melibatkan 100 pemain satu sama lain di dunia maya.<p>Permainan ini terinspirasi oleh konsep yang dipopulerkan oleh novel Jepang Battle Royale,</p> di mana orang terakhir yang berdiri dianggap sebagai pemenang. </p>
</div>
<div>
	<br>
	<img src="img/lol.png" style="margin-left: 230px; width: 150px; margin-top: 50px;">
		<h3 style="color: white; margin-left: 450px; margin-top: -70px">League of Legends</h3>
		<h5 style="color: white; margin-left: 450px; margin-top: 20px;">League of Legends adalah sebuah permainan video arena pertarungan daring multipemain<p> yang dikembangkan dan dipublikasikan oleh Riot Games untuk Microsoft Windows dan macOS.</p> Permainan tersebut terinspirasi oleh Warcraft III: The Frozen Throne dari seri Defense of the Ancients.
</div>
<div>
	<br>
	<img src="img/coc.png" style="margin-left: 230px; width: 150px; margin-top: 20px;">
		<h3 style="color: white; margin-left: 450px; margin-top: -120px">Clash of Clans</h3>
		<h5 style="color: white; margin-left: 450px; margin-top: 20px;">Clash of Clans adalah sebuah game Strategi di mana pemain membangun komunitas, melatih pasukan, dan menyerang pemain<p> lain untuk mendapatkan Emas, Trofi,Elixir dan Elixir hitam, membangun pertahanan yang melindungi pemain dari serangan pemain lain,<p> dan untuk melatih serta meningkatkan kemampuan maupun jumlah pasukan.</p> Permainan ini juga dilengkapi kampanye pseudo di mana pemain harus menyerang serangkaian benteng desa milik goblin.</p>
</div>
<br>
<br>
</body>
<footer style="background: rgba(28, 54, 85, .2);">
	<h4 style="color: white; margin-left: 540px; margin-top: -70px;"> Edited By : SISTEM INFORMATION 2018/PSI </h4>
</footer>
</html>