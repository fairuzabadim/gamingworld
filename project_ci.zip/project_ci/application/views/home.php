<!DOCTYPE html>
<html lang="en">
<head>
	<title>HOME</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>
<body>
	<section class="hero">
		<header>
			<div class="wrapper">
				<a href="#" class="hamburger"></a>
				<nav>
					<ul>
						<li><a href="home">Home</a></li>
						<li><a href="article">Article</a></li>
						<li><a href="games">Games</a></li>
						<li><a href="#">About</a></li>
					</ul>
					<a href="logoutuser.php" class="logout_btn">Logout</a>
				</nav>
			</div>
		</header>
			<section class="caption">
				<h2 class="caption">Gaming World</h2>
			</section>
	</section>
</body>
</html>