<!DOCTYPE html>
<html>
<head>
	<title>Login!</title>
    <link rel="stylesheet" type="text/css" href="css/login-styles.css">
    <script src="javascript.js"></script>
</head>
<body>
    <div class="bg">
        <img src="img/x.jpg" alt="">
    </div>
    <div class="wrap">
        <div class="box">
            <div class="box1">
                <div class="text">
                    <br>
                    <h2>Login</h2>
                    <div class="garis"></div>
                    <?php 
                        if(isset($_GET['msg'])) {
                            if($_GET['msg']) {
                                echo '<div style="margin-top: 5px;  
                                width: 100%; 
                                font-size: 12px; 
                                color: yellow; background: darkgoldenrod;
                                text-align: center;
                                padding: 5px;
                                border-radius: 3px;
                                transition: all 0.5 ease;">Username atau Password salah!</div>';
                            }
                        }
                    ?>
                </div>  
            
            <form name="form" onsubmit="return validasiLogin()" method="post" action="validasi-log.php">
                <div class="box-input">
                    <label>Username</label>
                    <input  type="text" name="user" id="username" placeholder="Username .." >
                </div>
                <div class="box-input">
                    <label>Password</label>
                    <input type="password" name="pass" id="password" placeholder="Password .." >
                </div>
                <div class="box-input">
                    <button type="submit" class="btn" name="login-pgw">Login</button>
                </div>
            </form>

            <div class="alert">
                <a href="login-mem.php">Anda Belum Punya Akun?<strong>   Daftar Akun</strong></a>
            </div>
            </div>
        </div>
</body>
</html>